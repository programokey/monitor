import './color_legend';
import { HeatmapCtrl } from './heatmap_ctrl';

export { HeatmapCtrl as PanelCtrl };
