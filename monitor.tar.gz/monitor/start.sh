#!/bin/bash
prometheus-2.3.1.linux-amd64/prometheus --config.file="prometheus-2.3.1.linux-amd64/prometheus.yml" 1>prometheus.log 2>prometheus.error &
grafana-5.2.2/bin/grafana-server -homepath=grafana-5.2.2 -config=grafana-5.2.2/conf/defaults.ini 1>grafana.log 2>grafana.error &
iris monitor -a=378E63271D5BE927443E17CBAAFE68DEFF383DA7 --account-address=faa1jxnsd70uhalp99huc8s7sdqgdnqc7mkd8yzg6g --chain-id=game-of-genesis --node="tcp://118.25.137.246:36657" > monitor.log &
