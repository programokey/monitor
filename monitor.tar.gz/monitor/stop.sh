#!/bin/sh
killall grafana-5.2.2/bin/grafana-server
killall prometheus-2.3.1.linux-amd64/prometheus
killall 'iris monitor'
